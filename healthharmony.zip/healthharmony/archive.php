<?php
gb_get_theme_file("/template-blog.php");
?>